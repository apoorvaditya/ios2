//
//  ViewController.swift
//  Calculation
//
//  Created by macbook_user on 9/12/17.
//  Copyright © 2017 macbook_user. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var theDisplay: UILabel!
    @IBOutlet weak var fullStack: UILabel!
    
    var userIsInMiddleOfEnteringANumber = false
    
    var calcBrain = CalculatorModel()
    
    @IBAction func clearStack(_ sender: UIButton) {
        calcBrain.clearStack()
        theDisplay.text = "0"
        fullStack.text = getCompleteStack()

    }
    @IBAction func enterPressed() {
        var enteredNumber = 0.0
        if(theDisplay.text == ".") {
            enteredNumber = 0.0
        } else {
            enteredNumber=Double(theDisplay.text!)!
        }
        print("number entered: \(enteredNumber)")
        userIsInMiddleOfEnteringANumber = false
        calcBrain.enterNumber(number: enteredNumber)
        fullStack.text = getCompleteStack()
        

    }
    @IBAction func operationPressed(_ sender: UIButton) {
        
        let whichOperation = sender.currentTitle!
        print("operation pressed: \(whichOperation)")
        if userIsInMiddleOfEnteringANumber {
            enterPressed()
        }
        let result = calcBrain.performOperation(whichOperation)
        theDisplay.text = "\(result)"
        fullStack.text = getCompleteStack()

    }
    
    @IBAction func unaryOperationPresses(_ sender: UIButton) {
        let unaryOperation = sender.currentTitle!
        print("unary operation pressed: \(unaryOperation)")
        let result = calcBrain.performUnaryOperation(unaryOperation)
        theDisplay.text = "\(result)"
        fullStack.text = getCompleteStack()
        

    }
    @IBAction func backspace(_ sender: UIButton) {
        var tempvar = theDisplay.text!
        
        //let length2 = tempvar.characters.count
        //print(length2)
        //let sublength = length2 - 1
        //let index = tempvar.index(tempvar.startIndex, offsetBy: sublength)
        //let display = tempvar.substring(to: index)
        tempvar.remove(at: tempvar.index(before: tempvar.endIndex))
        theDisplay.text = tempvar
        fullStack.text = getCompleteStack()
        

        
    }
    @IBAction func digitPressed(_ sender: UIButton) {
        let whichDigit = sender.currentTitle!
        print("digit pressed: \(whichDigit)")
        var currentDisplayText: String
        currentDisplayText = theDisplay.text!
        fullStack.text = getCompleteStack()
        
        if whichDigit == "pi"{
            currentDisplayText = String(calcBrain.specialSymbols(whichDigit))
            theDisplay.text = currentDisplayText
            
            
            
            enterPressed()
        }else{
            if userIsInMiddleOfEnteringANumber {
                theDisplay.text = currentDisplayText + whichDigit
            } else {
                theDisplay.text = sender.currentTitle!
                userIsInMiddleOfEnteringANumber  = true
            }
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


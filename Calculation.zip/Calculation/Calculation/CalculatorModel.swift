
import Foundation

var completeStack: [String] = []
var completeStack2 = ""
var isOperationDone = false

func getCompleteStack() -> String{
    return completeStack2
}

struct Stack {
    var data: [Double] = []
    
    mutating func push(_ number:Double) {
        data.append(number)
        completeStack.append(String(number))
        if(!isOperationDone) {
            completeStack2.append(" ")
            completeStack2.append(String(number))
        }
    }
    
    mutating func pop() -> Double {
        let top:Double = data[data.count - 1]
        data.removeLast()
        return top
    }
    mutating func flush(){
        data.removeAll()
    }
    
    func stackSize() -> Int {
        return data.count
    }
}


class CalculatorModel {
    
    var stack = Stack()
    
    func performOperation(_ operation: String) -> Double {
        print("Operation requested is  \(operation)")
        completeStack.append(operation)
        completeStack2.append(" "+operation)
        completeStack2.append(" ")
        completeStack2.append("=")
        var operand1: Double = 0.0
        var operand2: Double = 0.0
        
        if stack.stackSize() >= 2{
            operand2 = stack.pop()
            operand1 = stack.pop()
        }
        else if stack.stackSize() >= 1{
            operand2 = stack.pop()
            operand1 = 0
        }
        else{
            operand2 = 0
            operand1 = 0
        }
        
        let result: Double
        if operation == "+" {
            result = operand1 + operand2
        } else if operation == "-" {
            result = operand1 - operand2
        } else if operation == "x" {
            result = operand1 * operand2
        } else if operation == "/" {
            result = operand1 / operand2
        } else {
            result = 0
        }
        isOperationDone = true
        stack.push(result)
        isOperationDone = false
        print("Current Stack is \(stack)")
        return result
    }
    
    func performUnaryOperation(_ operation: String) -> Double {
        var operand1: Double = 0.0
        let result: Double
        completeStack.append(operation)
        print("Operation is "+operation)
        completeStack2.append(" " + operation)
        completeStack2.append(" ")
        completeStack2.append("=")
        if stack.stackSize() >= 1{
            operand1 = stack.pop()
        }else{
            print("Please provide more operands")
        }
        
        switch operation {
        case "√":
            result = sqrt(operand1)
        case "±":
            result = -operand1
        case "sin":
            operand1 = ((operand1*Double.pi)/180)
            result = sin(operand1)
        case "cos":
            operand1 = ((operand1*Double.pi)/180)
            result = cos(operand1)
        default:
            result = 0.0
        }
        isOperationDone = true
        stack.push(result)
        isOperationDone = false
        return result
    }
    
    func specialSymbols(_ symbol: String) -> Double {
        let result: Double
        if symbol == "pi"{
            result = Double.pi
        }
        else{
            result = 0.0
        }
        return result
    }
    
    func clearStack() {
        var size = stack.stackSize()
        while size > 0 {
            stack.flush()
            size -= 1
        }
        print(stack)
        print("the stack is empty")
        completeStack = []
        completeStack2 = ""
    }
    
    func enterNumber(number: Double) {
        print("Data input is \(number)")
        stack.push(number)
        print(stack)
    }
}


